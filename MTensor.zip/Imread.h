#ifndef IMREAD_H
#define IMREAD_H

class Imread
{
};
#endif IMREAD_H
